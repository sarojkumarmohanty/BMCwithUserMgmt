-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: user_mgmt
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_user` (
  `user_id` varchar(12) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `password` varchar(16) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone_no` varchar(45) NOT NULL,
  `aadhar_no` varchar(15) DEFAULT NULL,
  `aadhar_id_path` varchar(45) DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `otp` int DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` varchar(12) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `is_active` varchar(5) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `phone_no_UNIQUE` (`phone_no`),
  UNIQUE KEY `aadhar_no_UNIQUE` (`aadhar_no`),
  KEY `tbl_user_role_id_fk_idx` (`role_id`),
  KEY `tbl_user_created_by_fk_idx` (`created_by`),
  CONSTRAINT `tbl_user_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `tbl_user` (`user_id`),
  CONSTRAINT `tbl_user_role_id_fk` FOREIGN KEY (`role_id`) REFERENCES `tbl_role` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES ('amit','Amit Sahoo','Amit@123','amit@gmail.com','9861116414','123456789352','d:\\utf\\amit.jpeg',1,NULL,'2022-11-09',NULL,NULL,'YES','APPR'),('anil','Anil Das','anil@123','anil@gmail.com','9848667656','12455222278','d:\\utf\\college_admission.png',3,NULL,'2022-11-10',NULL,NULL,'YES','PEND'),('little','Little','little@123','little@gmail.com','9864443423','12345678','d:\\utf\\green.jpg',2,NULL,'2022-11-10','amit',NULL,'YES','APPR'),('suman','Suman Das','suman@123','suman@gmail.com','9879823534','12345222278','d:\\utf\\github.txt',2,NULL,'2022-11-10','amit',NULL,'YES','APPR'),('sumit','Sumit Das','sumit@123','sumit@gmail.com','9877764534','1234544478','d:\\utf\\exception-hierarchy-in-java.png',3,NULL,'2022-11-10','amit',NULL,'YES','PEND');
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-10 15:44:32
