-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: user_mgmt
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `birth_certificate`
--

DROP TABLE IF EXISTS `birth_certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `birth_certificate` (
  `certificate_id` int NOT NULL AUTO_INCREMENT,
  `child_name` varchar(45) NOT NULL,
  `child_dob` datetime NOT NULL,
  `child_blood_group` varchar(5) NOT NULL,
  `child_weight` double NOT NULL,
  `child_gender` varchar(5) NOT NULL,
  `hospital_name` varchar(45) DEFAULT NULL,
  `hospital_doc_path` varchar(45) DEFAULT NULL,
  `father_name` varchar(45) NOT NULL,
  `mother_name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `address_proof` varchar(45) NOT NULL,
  `applied_on` date DEFAULT NULL,
  `applied_by` varchar(12) DEFAULT NULL,
  `approved_on` date DEFAULT NULL,
  `approved_by` varchar(12) DEFAULT NULL,
  `application_status` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`certificate_id`),
  KEY `birth_cirtificate_applied_by_fk_idx` (`applied_by`),
  KEY `birth_cirtificate_approved_by_fk_idx` (`approved_by`),
  CONSTRAINT `birth_cirtificate_applied_by_fk` FOREIGN KEY (`applied_by`) REFERENCES `tbl_user` (`user_id`),
  CONSTRAINT `birth_cirtificate_approved_by_fk` FOREIGN KEY (`approved_by`) REFERENCES `tbl_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1014 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `birth_certificate`
--

LOCK TABLES `birth_certificate` WRITE;
/*!40000 ALTER TABLE `birth_certificate` DISABLE KEYS */;
INSERT INTO `birth_certificate` VALUES (1010,'Ansuman Das','2022-10-11 12:18:00','B+',3.5,'M','City','d:\\utf\\hospital.bmp','Sumit Das','Sunita Das','Old Town, Bhubaneswar','d:\\utf\\addr.bmp','2022-11-11','sumit','2022-11-11','little','APPR'),(1011,'Prashant','2022-11-11 13:23:00','o+',5,'M','unit-6','d:\\utf\\college_admission.png','ABHINASH M','A.MOHAPATRA','BBSR','d:\\utf\\college_admission.png','2022-11-11','anil','2022-11-11','little','APPR'),(1012,'Prashant','2022-11-11 13:23:00','o+',5,'M','unit-6','d:\\utf\\hospital.bmp','ABHINASH M','A.MOHAPATRA','BBSR','d:\\utf\\green.jpg','2022-11-11','anil','2022-11-11','little','APPR'),(1013,'Jr siba','2022-06-11 15:56:00','AB+',2.3,'M','Capital Hopital','d:\\utf\\io.gif','Siba Prasad','Siba Wife','Old Town, Bhubaneswar','d:\\utf\\frame.jpg','2022-11-11','siba','2022-11-11','little','APPR');
/*!40000 ALTER TABLE `birth_certificate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-11 16:03:04
